#!/bin/bash
xhost +
