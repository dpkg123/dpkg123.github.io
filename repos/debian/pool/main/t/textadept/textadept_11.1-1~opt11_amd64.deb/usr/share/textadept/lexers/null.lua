-- Copyright 2006-2021 Mitchell. See LICENSE.
-- Null LPeg lexer.

return require('lexer').new('null')
