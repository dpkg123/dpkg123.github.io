# HTML

The html module for Textadept.
It provides utilities for editing HTML code.

---
